export class Vehiculo {}
